import pip


pipPackages = pip.get_installed_distributions()
dependencies = ["colorama", "requests", "download"]
packages = [package.project_name for package in pipPackages]


def checkForDependencies():
    for i in dependencies:
        if not i in packages:
            print("Missing dependencie(s): {0} ".format(i))
            installDependencies(i)

def installDependencies(package):
    print("Downloading dependencies: " + package)
    pip.main(['install', package])

checkForDependencies()